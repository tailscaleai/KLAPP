
import { useState } from "react";
export default function Home() {
  const [file,setFile]=useState(null);
  const [msg,setMsg]=useState("");
  const upload=async()=>{
    const f=new FormData();
    f.append("video",file);
    setMsg("Processing...");
    await fetch("http://localhost:5000/upload",{method:"POST",body:f});
    setMsg("Done");
  };
  return (
    <main style={{padding:40}}>
      <h1>Klap Clone</h1>
      <input type="file" onChange={e=>setFile(e.target.files[0])}/>
      <button onClick={upload}>Upload</button>
      <p>{msg}</p>
    </main>
  );
}
