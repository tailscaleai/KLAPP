
import sys, subprocess
subprocess.run(["ffmpeg","-y","-i",sys.argv[1],"-ac","1","-ar","16000",sys.argv[2]])
