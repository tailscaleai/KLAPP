
import json, sys
def fmt(t):
    h=int(t//3600);m=int(t%3600//60);s=int(t%60);ms=int((t-int(t))*1000)
    return f"{h:02}:{m:02}:{s:02},{ms:03}"
seg=json.load(open(sys.argv[1]))
with open(sys.argv[2],"w") as f:
    i=1
    for s in seg:
        f.write(f"{i}\n{fmt(s['start'])} --> {fmt(s['end'])}\n{s['text']}\n\n")
        i+=1
