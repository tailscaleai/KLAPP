
import whisper, sys, json
model = whisper.load_model("base")
res = model.transcribe(sys.argv[1])
json.dump(res["segments"], open(sys.argv[2],"w"))
