
import json, sys
segments=json.load(open(sys.argv[1]))
best=[]
for s in segments:
    d=s["end"]-s["start"]
    w=len(s["text"].split())
    if d>5 and w/d>2.2:
        best.append({"start":s["start"],"end":s["end"]})
json.dump(best[:5], open(sys.argv[2],"w"))
