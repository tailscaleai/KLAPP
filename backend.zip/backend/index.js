
import express from "express";
import multer from "multer";
import cors from "cors";
import ffmpeg from "fluent-ffmpeg";
import ffmpegPath from "ffmpeg-static";
import fs from "fs";
import { execSync } from "child_process";

ffmpeg.setFfmpegPath(ffmpegPath);

const app = express();
app.use(cors());
app.use(express.static("."));

const upload = multer({ dest: "uploads/" });

app.post("/upload", upload.single("video"), async (req, res) => {
  const input = req.file.path;
  const job = Date.now();
  const dir = `clips/${job}`;
  fs.mkdirSync(dir, { recursive: true });

  execSync(`python ai/extract_audio.py ${input} audio.wav`);
  execSync(`python ai/transcribe.py audio.wav segments.json`);
  execSync(`python ai/pick_moments.py segments.json best.json`);
  execSync(`python ai/make_subtitles.py segments.json subs.srt`);

  const best = JSON.parse(fs.readFileSync("best.json"));

  best.forEach((m, i) => {
    ffmpeg(input)
      .setStartTime(m.start)
      .setDuration(m.end - m.start)
      .videoFilters(
        "subtitles=subs.srt:force_style='Fontsize=64,PrimaryColour=&H00FFFF,Outline=3,Alignment=2'"
      )
      .output(`${dir}/clip_${i}.mp4`)
      .run();
  });

  res.json({ success: true, clips: best.length });
});

app.listen(5000, () => console.log("Backend running on :5000"));
